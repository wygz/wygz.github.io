#include <bits/stdc++.h>
using namespace std;
template <typename T> void read(T &t) {
	t=0; char ch=getchar(); int f=1;
	while (ch<'0'||ch>'9') { if (ch=='-') f=-1; ch=getchar(); }
	do { (t*=10)+=ch-'0'; ch=getchar(); } while ('0'<=ch&&ch<='9'); t*=f;
}
typedef long long ll;
const ll INF=1e17;
const int maxn=(1e5)+10;
int n,m;
ll f[310][110],s[maxn];
ll sqr(ll x) { return x*x; }
void solve1() {
	for (int i=0;i<=n;i++)
	for (int j=0;j<=m;j++) f[i][j]=INF;
	f[0][0]=0;
	for (int i=1;i<=n;i++)
	for (int j=1;j<=m;j++) {
		for (int k=0;k<i;k++)
			f[i][j]=min(f[k][j-1]+sqr(s[i]-s[k]),f[i][j]);
	}
	printf("%lld\n",f[n][m]);
}
ll dp[maxn],ans,tmp;
int cnt[maxn];
int solve(ll mid) {
	dp[0]=0; cnt[0]=0;
	for (int i=1;i<=n;i++) {
		dp[i]=INF;
		for (int j=0;j<i;j++) {
			tmp=dp[j]+sqr(s[i]-s[j])+mid;
			if (tmp<dp[i]) dp[i]=tmp,cnt[i]=cnt[j]+1;
			else if (tmp==dp[i]) cnt[i]=min(cnt[i],cnt[j]+1);
		}
	}
	return cnt[n];
}
int d[maxn],l,r;
ll getUP(int j,int k) {
	return dp[j]+sqr(s[j])-dp[k]-sqr(s[k]);
}
ll getDOWN(int j,int k) {
	return s[j]-s[k];
}
int Solve(ll mid) {
	dp[0]=0; cnt[0]=0; d[l=r=1]=0;
	for (int i=1;i<=n;i++) {
		dp[i]=INF;
		while (l<r&&getUP(d[l+1],d[l])<=2*s[i]*getDOWN(d[l+1],d[l])) l++;
		dp[i]=dp[d[l]]+sqr(s[i]-s[d[l]])+mid;
		cnt[i]=cnt[d[l]]+1;
		while (l<r&&getUP(i,d[r])*getDOWN(d[r],d[r-1])<=getUP(d[r],d[r-1])*getDOWN(i,d[r])) r--;
		d[++r]=i;
	}
	return cnt[n];
}
void solve2() {
	ll l=0,r=INF/m,mid;
	ll res=0;
	while (l<=r) {
		mid=(l+r)/2;
		if (solve(mid)<m) r=mid-1;
		else {
			l=mid+1;
			res=mid;
		}
	}
	int tmp=solve(res);
	if (tmp==m) ans=dp[n]-(ll)res*m;
	else ans=dp[n]-(ll)(res+1)*m;
	printf("%lld\n",ans);
}
void solve3() {
	ll l=0,r=INF/m,mid;
	ll res=0;
	while (l<=r) {
		mid=(l+r)/2;
		if (Solve(mid)<m) r=mid-1;
		else {
			l=mid+1;
			res=mid;
		}
	}
	int tmp=Solve(res);
	if (tmp==m) ans=dp[n]-(ll)res*m;
	else ans=dp[n]-(ll)(res+1)*m;
	printf("%lld\n",ans);
}
int main() {
	read(n); read(m);
	for (int i=1;i<=n;i++) read(s[i]),s[i]+=s[i-1];
	if (n<=300&&m<=100) solve1();
	//else if (n<=3000&&m<=1000) solve2();
	else solve3();
	return 0;
}
/*
  0. Enough array size? Enough array size? Enough array size? Interger overflow?
  
  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?
    
  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?
    
  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/
